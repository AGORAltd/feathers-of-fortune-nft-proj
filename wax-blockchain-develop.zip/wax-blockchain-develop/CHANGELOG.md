# Changelog

## Pending (vx.y.zwax<sub version>)

BREAKING CHANGES:

FEATURES:

IMPROVEMENTS:

BUG FIXES:

## v2.0.5wax01

BREAKING CHANGES:
- EOSIO 2.0.5 upgrade by cc32d9

FEATURES:

IMPROVEMENTS:
- Update docker image for mainnnet sample

BUG FIXES:

## wax-1.8.4-1.0.0

BREAKING CHANGES:
- [KEW-1564] Bump to v1.8.4.

FEATURES:

IMPROVEMENTS:

BUG FIXES:

## wax-1.8.3-1.0.0

BREAKING CHANGES:
- [KEW-1564] Bump to v1.8.3.

FEATURES:

IMPROVEMENTS:
- [KEW-1438] Upgrade instructions for 1.8.1-1.0.0

BUG FIXES:
- [KEW-1450] Fix documentation
- [KEW-1450] Fix upgrade documentation

## wax-1.8.1-1.0.0

BREAKING CHANGES:
- [KEW-1378] Bump to v1.8.1.

FEATURES:

IMPROVEMENTS:

BUG FIXES:
- [KEW-1434] Fix/update sample/hello-world
- [KEW-1396] Fix test fixture initial genesis timestamp
- [KEW-1430] Fix 'verify_rsa_sha256_sig' exportation.
- [KEW-1436] Fix WAX (and EOSIO) unit tests

## wax-1.6.1-1.1.0

BREAKING CHANGES:
- [KEW-1316] Renaming EOSIO with WAX.

FEATURES:

IMPROVEMENTS:
- [KEW-1299] Update README file, add this Changelog file

BUG FIXES:
- [KEW-1320] Add patch and documentation for FC library linking problem
