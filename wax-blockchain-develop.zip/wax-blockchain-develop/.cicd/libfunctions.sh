#!/bin/bash

function perform {
    echo "$ $1"
    eval $1
}
