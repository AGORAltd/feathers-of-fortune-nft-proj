## Description
Get transaction id given transaction object

## Positional Parameters

- `transaction` _TEXT_ - The JSON string or filename defining the transaction which transaction id we want to retrieve (required)

## Options

  `-h,--help`                   Print this help message and exit