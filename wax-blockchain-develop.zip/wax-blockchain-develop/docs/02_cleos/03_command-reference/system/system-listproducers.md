## Description

List producers

## Positional Arguments

## Options

`-h,--help`                   Print this help message and exit
`-j,--json`                   Output in JSON format
`-l,--limit` _UINT_             The maximum number of rows to return
`-L,--lower` _TEXT_             lower bound value of key, defaults to first