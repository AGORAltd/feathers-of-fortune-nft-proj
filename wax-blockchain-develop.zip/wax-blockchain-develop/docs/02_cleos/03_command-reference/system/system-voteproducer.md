## Subcommands
- [voteproducer proxy](system-voteproducer-proxy) - Vote your stake through a proxy
- [voteproducer prods](system-voteproducer-prods) - Vote for one or more producers
- [voteproducer approve](system-voteproducer-approve) -Add one producer to list of voted producers
- [voteproducer unapprove](system-voteproducer-unapprove) - Remove one producer from list of voted producers