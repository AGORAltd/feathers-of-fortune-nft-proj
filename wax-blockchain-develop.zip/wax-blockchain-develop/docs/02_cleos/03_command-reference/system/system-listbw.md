## Description

List delegated bandwidth

## Positional Arguments
- `account` _TEXT_ - The account delegated bandwidth

## Options
`-j,--json` - Output in JSON format
`-h,--help` - Print this help message and exit

## Examples
