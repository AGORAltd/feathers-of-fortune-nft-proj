## Description

Retrieve version information of the client

## Positionals
none
## Usage

```sh
cleos version client
```
