## Description

Retrieve version information

## Command

```sh
cleos version
```

## Subcommands
[client](client) - Retrieve version information of the client

```sh
cleos version client
```

## Output


```console
Build version: 7f854a61
```
