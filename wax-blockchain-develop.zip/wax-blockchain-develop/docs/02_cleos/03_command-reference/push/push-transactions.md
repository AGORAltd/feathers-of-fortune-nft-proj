## Description
Push an array of arbitrary JSON transactions

## Positional Arguments
Pushes an array of arbitrary JSON transactions.
## Options
This command has no options
## Examples
