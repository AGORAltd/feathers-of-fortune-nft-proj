## Description

Opens an existing wallet

## Positionals
None
## Options
- `-n, --name` _TEXT_ - The name of the wallet to open.
## Usage


```sh
cleos wallet open
```
or
```sh
cleos wallet open -n second-wallet
```

## Outputs


```console
Opened: default
```
