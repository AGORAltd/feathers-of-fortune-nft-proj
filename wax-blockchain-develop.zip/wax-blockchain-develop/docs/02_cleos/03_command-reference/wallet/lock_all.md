## Description
Locks all unlocked wallets


## Positionals
None
## Options
None
## Usage


```sh
cleos wallet lock_all
```

## Outputs


```console
Locked All Wallets
```
