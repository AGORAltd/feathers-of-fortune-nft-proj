## Description

Lists opened wallets, * = unlocked

## Positionals
None

## Options
None

## Usage


```sh
cleos wallet list
```

## Outputs


```console
Wallets:
[
  "default *",
  "second-wallet *"
]
```

or when there are no wallets:

```console
Wallets:
[
]
```
