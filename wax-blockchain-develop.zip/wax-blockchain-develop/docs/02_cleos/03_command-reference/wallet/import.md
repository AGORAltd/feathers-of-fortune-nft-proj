## Description
Imports private key into wallet

## Positionals
None

## Options
- `-n, --name` _TEXT_ - The name of the wallet to import key into.
- `--private-key` _TEXT_ - Private key in WIF format to import.