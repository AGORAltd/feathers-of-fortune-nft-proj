## Goal

Query infomation of a table

## Before you begin

* Install the currently supported version of `cleos`

* Understand the following:
  * What is an account
  * What is a table
  * What is a scope of table

## Steps

```sh
cleos get table ACCOUNT SCOPE TABLE
```