---
content_title: Platforms
---

* [Amazon Linux 2](amazon_linux-2.md)
* [CentOS 7.7](centos-7.7.md)
* [MacOS 10.14](macos-10.14.md)
* [Ubuntu 18.04](ubuntu-18.04.md)
